﻿using CRUD_MT.Data;
using CRUD_MT.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

namespace CRUD_MT.Controllers
{
        public class ProductController : Controller
        {
            private readonly MTDbContext _context;
            private const int PageSize = 5;

            public ProductController(MTDbContext context)
            {
                _context = context;
            }

            public async Task<IActionResult> Index(int page = 1)
            {
                var query = _context.Product
                    .Include(p => p.Category)
                    .OrderBy(p => p.ProductId)
                    .AsNoTracking();

                var paginated = await ListView<Product>.CreateAsync(query, page, PageSize);
                return View(paginated);
            }

            public async Task<IActionResult> Create()
            {
                ViewBag.Category = await _context.Category.ToListAsync();
                return View();
            }

            [HttpPost]
            public async Task<IActionResult> Create(Product product)
            {
                if (product!= null && ModelState.IsValid)
                {
                    _context.Add(product);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                ViewBag.Category = await _context.Category.ToListAsync();
                return View(product);
            }

            public async Task<IActionResult> Edit(int id)
            {
                var product = await _context.Product.FindAsync(id);
                ViewBag.Category = await _context.Category.ToListAsync();
                return View(product);
            }

            [HttpPost]
            public async Task<IActionResult> Edit(Product product)
            {
                if (ModelState.IsValid)
                {
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                ViewBag.Category = await _context.Category.ToListAsync();
                return View(product);
            }

            public async Task<IActionResult> Delete(int id)
            {
                var product = await _context.Product.Include(p => p.Category)
                    .FirstOrDefaultAsync(p => p.ProductId == id);
                return View(product);
            }

            [HttpPost, ActionName("Delete")]
            public async Task<IActionResult> DeleteConfirmed(int id)
            {
                var product = await _context.Product.FindAsync(id);
            if (product != null)
            {
                _context.Product.Remove(product);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
            }
        }
    }
