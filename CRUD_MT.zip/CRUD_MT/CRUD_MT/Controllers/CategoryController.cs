﻿using CRUD_MT.Data;
using CRUD_MT.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUD_MT.Controllers
{
    public class CategoryController : Controller
    {
        private readonly MTDbContext context;

        public CategoryController(MTDbContext context) 
        {
            this.context = context;
        }

        public async Task<IActionResult> Index()
        {
            var Category = await context.Category.ToListAsync();
            return View(Category);
        }
        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(Category category)
        {
                if (category != null && ModelState.IsValid)
                {
                    context.Add(category);
                    await context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            return View(category);
        }

        public async Task<IActionResult> Edit(int id)
        {
            var category = await context.Category.FindAsync(id);
            return category == null ? NotFound() : View(category);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                context.Update(category);
                await context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(category);
        }

        public async Task<IActionResult> Delete(int id)
        {
            var category = await context.Category.FindAsync(id);
            return category == null ? NotFound() : View(category);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var category = await context.Category.FindAsync(id);
            context.Category.Remove(category);
            await context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}
