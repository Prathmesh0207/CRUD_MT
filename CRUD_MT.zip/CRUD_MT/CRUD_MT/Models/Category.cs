﻿using System.ComponentModel.DataAnnotations;
using System.Security.Permissions;

namespace CRUD_MT.Models
{
    public class Category
    {
        
        public int CategoryId { get; set; }

        [Required]
        [StringLength(100)]
        public string CategoryName { get; set; } = String.Empty;

        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}
