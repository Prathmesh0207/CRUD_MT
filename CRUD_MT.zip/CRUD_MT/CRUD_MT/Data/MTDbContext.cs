﻿using CRUD_MT.Models;
using Microsoft.EntityFrameworkCore;

namespace CRUD_MT.Data
{
    public class MTDbContext :DbContext
    {
        public MTDbContext(DbContextOptions options) : base(options)
        {     
        }
        public DbSet<Product> Product { get; set; }
        public DbSet<Category> Category { get; set; }
    }
}
